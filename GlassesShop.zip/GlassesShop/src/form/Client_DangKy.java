package form;



import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;



public class Client_DangKy extends ActionForm{
	private String tenKH;
	private String ngaySinh;
	private String diaChi;
	private String soDienThoai;
	private String email;
	private String matKhau;
	private String maGD;
	private String userName;
	private int gioiTinh;
	
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public String getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(String ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	public String getSoDienThoai() {
		return soDienThoai;
	}
	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getMaGD() {
		return maGD;
	}
	public void setMaGD(String maGD) {
		this.maGD = maGD;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setGioiTinh(int gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public int getGioiTinh() {
		return gioiTinh;
	}
	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		ActionErrors actionErrors=new ActionErrors();
		if(StringProcess.notVaild(tenKH))
		{
			actionErrors.add("tenKHrror",new ActionMessage("error.tenKH"));
		}
		if(StringProcess.notVaild(ngaySinh) || !ngaySinh.matches("(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/((19|20)\\d\\d)"))
		{
			actionErrors.add("ngaySinhError",new ActionMessage("error.ngaySinh"));
		}
		if(StringProcess.notVaild(diaChi))
		{
			actionErrors.add("diaChiError",new ActionMessage("error.diaChi"));
		}
		if(StringProcess.notVaild(soDienThoai) || StringProcess.notVaildNumber(soDienThoai))
		{
			actionErrors.add("soDienThoaiError",new ActionMessage("error.soDienThoai"));
		}
		if(StringProcess.notVaild(email) || !email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"))
		{
			actionErrors.add("emailError",new ActionMessage("error.Email"));
		}
		if(StringProcess.notVaild(matKhau))
		{
			actionErrors.add("matKhauError",new ActionMessage("error.matKhau"));
		}
//		if(StringProcess.notVaildNumber(maGD))
//		{
//			actionErrors.add("maGiaDinhError",new ActionMessage("error.maGiaDinh"));
//		}
		if(StringProcess.notVaild(userName))
		{
			actionErrors.add("userNameError",new ActionMessage("error.userName"));
		}
		
		return actionErrors;
	}
}
