package form;

import org.apache.struts.action.ActionForm;

public class DangXuatForm extends ActionForm{
	
}
