package form;

import bean.SanPham;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

public class GioHangForm extends ActionForm {
	private String maSP="";
	private ArrayList<SanPham> listSanPham;
	private SanPham sanPham;
	private float tongTien;
	private int soLuong;
	private String yeuCau;
	
	public float getTongTien() {
		return tongTien;
	}

	public void setTongTien(float tongTien) {
		this.tongTien = tongTien;
	}

	public SanPham getSanPham() {
		return sanPham;
	}

	public void setSanPham(SanPham sanPham) {
		this.sanPham = sanPham;
	}

	public String getMaSP() {
		return maSP;
	}

	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}

	public ArrayList<SanPham> getListSanPham() {
		return listSanPham;
	}

	public void setListSanPham(ArrayList<SanPham> listSanPham) {
		this.listSanPham = listSanPham;
	}

	public String getYeuCau() {
		return yeuCau;
	}

	public void setYeuCau(String yeuCau) {
		this.yeuCau = yeuCau;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
}
