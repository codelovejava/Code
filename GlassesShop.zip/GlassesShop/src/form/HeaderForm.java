package form;

import org.apache.struts.action.ActionForm;

public class HeaderForm extends ActionForm{
	private String tinhTrang;
	
	public String getTinhTrang() {
		return tinhTrang;
	}

	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}
	

}
