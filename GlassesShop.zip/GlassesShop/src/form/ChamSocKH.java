package form;

import java.sql.Date;
import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import bean.Benh;
import bean.ChamSocKhachHang;
import bean.CoTheBanChuaBiet;
import bean.KhachHang;

public class ChamSocKH extends ActionForm {
	private int maKH;
	private String userName;
	private String tenKH;
	private float doCan;
	private String noiDung;
	private int maND;
	private String noiDungGoiY;
	private ChamSocKhachHang chamSocKhachHang;
	private CoTheBanChuaBiet banChuaBiet;
	private KhachHang khachHang;
	private Date ngaySinh;
	private String diaChi;
	private String soDienThoai;
	private String email;
	private String matKhau;
	private int maGD;
	private String gioiTinh;

	
	
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	public String getSoDienThoai() {
		return soDienThoai;
	}
	public void setSoDienThoai(String soDienThoai) {
		this.soDienThoai = soDienThoai;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public int getMaGD() {
		return maGD;
	}
	public void setMaGD(int maGD) {
		this.maGD = maGD;
	}
	public String getGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public KhachHang getKhachHang() {
		return khachHang;
	}
	public void setKhachHang(KhachHang khachHang) {
		this.khachHang = khachHang;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTenKH() {
		return tenKH;
	}
	public void setTenKH(String tenKH) {
		this.tenKH = tenKH;
	}
	public int getMaKH() {
		return maKH;
	}
	public void setMaKH(int maKH) {
		this.maKH = maKH;
	}
	public ChamSocKhachHang getChamSocKhachHang() {
		return chamSocKhachHang;
	}
	public void setChamSocKhachHang(ChamSocKhachHang chamSocKhachHang) {
		this.chamSocKhachHang = chamSocKhachHang;
	}
	public CoTheBanChuaBiet getBanChuaBiet() {
		return banChuaBiet;
	}
	public void setBanChuaBiet(CoTheBanChuaBiet banChuaBiet) {
		this.banChuaBiet = banChuaBiet;
	}
	
	public float getDoCan() {
		return doCan;
	}
	public void setDoCan(float doCan) {
		this.doCan = doCan;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public int getMaND() {
		return maND;
	}
	public void setMaND(int maND) {
		this.maND = maND;
	}
	public String getNoiDungGoiY() {
		return noiDungGoiY;
	}
	public void setNoiDungGoiY(String noiDungGoiY) {
		this.noiDungGoiY = noiDungGoiY;
	}
}
