package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import bean.TimKiem;

public class TimKiemForm extends ActionForm{
	private String tuKhoa;
	private String tuTimKiemCoThe;
	private int luotXem;
	private ArrayList<TimKiem> listTK;
	private String submit;
	
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getTuKhoa() {
		return tuKhoa;
	}
	public void setTuKhoa(String tuKhoa) {
		this.tuKhoa = tuKhoa;
	}
	public String getTuTimKiemCoThe() {
		return tuTimKiemCoThe;
	}
	public void setTuTimKiemCoThe(String tuTimKiemCoThe) {
		this.tuTimKiemCoThe = tuTimKiemCoThe;
	}
	public int getLuotXem() {
		return luotXem;
	}
	public void setLuotXem(int luotXem) {
		this.luotXem = luotXem;
	}
	public ArrayList<TimKiem> getListTK() {
		return listTK;
	}
	public void setListTK(ArrayList<TimKiem> listTK) {
		this.listTK = listTK;
	}
	

}
