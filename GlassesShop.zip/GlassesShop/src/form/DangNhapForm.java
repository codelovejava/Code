package form;

import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;

import bean.SanPham;

public class DangNhapForm extends ActionForm{
	private String userName; // dau vao, dau ra 
	private String matKhau;
	private String thongBao;
	private ArrayList<SanPham> listSPSale;
	private ArrayList<SanPham> listSPHot;
	private ArrayList<SanPham> listSP;
	private String timKiem;
	private String loaiSP;
	private static String trangThai="Dang Nhap";
	private int MaSP;
	private SanPham sanPham;
	private String tenSP;
	private int soLuong;
	private float giaTien;
	private String xuatXu;
	private int maDM;
	private Date ngayNhapVe;
	private String urlImage;
	
	public SanPham getSanPham() {
		return sanPham;
	}
	public void setSanPham(SanPham sanPham) {
		this.sanPham = sanPham;
	}
	public int getMaSP() {
		return MaSP;
	}
	public void setMaSP(int maSP) {
		MaSP = maSP;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	public float getGiaTien() {
		return giaTien;
	}
	public void setGiaTien(float giaTien) {
		this.giaTien = giaTien;
	}
	public String getXuatXu() {
		return xuatXu;
	}
	public void setXuatXu(String xuatXu) {
		this.xuatXu = xuatXu;
	}
	public int getMaDM() {
		return maDM;
	}
	public void setMaDM(int maDM) {
		this.maDM = maDM;
	}
	public Date getNgayNhapVe() {
		return ngayNhapVe;
	}
	public void setNgayNhapVe(Date ngayNhapVe) {
		this.ngayNhapVe = ngayNhapVe;
	}
	public String getUrlImage() {
		return urlImage;
	}
	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}
	public ArrayList<SanPham> getListSPSale() {
		return listSPSale;
	}
	public void setListSPSale(ArrayList<SanPham> listSPSale) {
		this.listSPSale = listSPSale;
	}
	public ArrayList<SanPham> getListSPHot() {
		return listSPHot;
	}
	public void setListSPHot(ArrayList<SanPham> listSPHot) {
		this.listSPHot = listSPHot;
	}
	public ArrayList<SanPham> getListSP() {
		return listSP;
	}
	public void setListSP(ArrayList<SanPham> listSP) {
		this.listSP = listSP;
	}
	public String getTimKiem() {
		return timKiem;
	}
	public void setTimKiem(String timKiem) {
		this.timKiem = timKiem;
	}
	public String getLoaiSP() {
		return loaiSP;
	}
	public void setLoaiSP(String loaiSP) {
		this.loaiSP = loaiSP;
	}
	public String getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMatKhau() {
		return matKhau;
	}
	public void setMatKhau(String matKhau) {
		this.matKhau = matKhau;
	}
	public String getThongBao() {
		return thongBao;
	}
	public void setThongBao(String thongBao) {
		this.thongBao = thongBao;
	}
	

	@Override
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		// TODO Auto-generated method stub
		ActionErrors actionErrors=new ActionErrors();
		if(userName!=null||matKhau!=null){
		if("Dang Nhap".equals(trangThai)&&  StringProcess.notVaild(userName)){
			actionErrors.add("userNameError",new ActionMessage("error.userName"));
		}
		if("Dang Nhap".equals(trangThai)&&StringProcess.notVaild(matKhau)){
			actionErrors.add("matKhauError",new ActionMessage("error.matKhau"));
			}
		}
		return actionErrors;
	}
	
}
