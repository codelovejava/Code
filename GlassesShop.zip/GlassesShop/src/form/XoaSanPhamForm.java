package form;

import org.apache.struts.action.ActionForm;

public class XoaSanPhamForm extends ActionForm{
	private String maSP;

	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}

	public String getMaSP() {
		return maSP;
	}
}
