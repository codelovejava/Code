package form;

import org.apache.struts.action.ActionForm;

import bean.ThongKe;

public class ThongKeForm extends ActionForm{
	private int soLuongKH;
	private float phanTramSP;
	private float soLanSale;
	private int doanhSo;
	private int nam;
	
	private ThongKe thongKe;
	public float getSoLuongKH() {
		return soLuongKH;
	}
	public void setSoLuongKH(int soLuongKH) {
		this.soLuongKH = soLuongKH;
	}
	public void setDoanhSo(int doanhSo) {
		this.doanhSo = doanhSo;
	}
	public float getPhanTramSP() {
		return phanTramSP;
	}
	public void setPhanTramSP(float phanTramSP) {
		this.phanTramSP = phanTramSP;
	}
	public float getSoLanSale() {
		return soLanSale;
	}
	public void setSoLanSale(float soLanSale) {
		this.soLanSale = soLanSale;
	}
	public float getDoanhSo() {
		return doanhSo;
	}
	public void setDoanhSo(float doanhSo) {
		doanhSo = doanhSo;
	}
	public int getNam() {
		return nam;
	}
	public void setNam(int nam) {
		this.nam = nam;
	}
	public ThongKe getThongKe() {
		return thongKe;
	}
	public void setThongKe(ThongKe thongKe) {
		this.thongKe = thongKe;
	}
	

}
