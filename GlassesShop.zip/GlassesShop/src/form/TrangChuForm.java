package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import bean.SanPham;

public class TrangChuForm extends ActionForm{
	private ArrayList<SanPham> listSPSale;
	private ArrayList<SanPham> listSPHot;
	private ArrayList<SanPham> listSP;
	private String timKiem;
	private String loaiSP;
	private String trangThai;
	public ArrayList<SanPham> getListSPSale() {
		return listSPSale;
	}
	public void setListSPSale(ArrayList<SanPham> listSPSale) {
		this.listSPSale = listSPSale;
	}
	public ArrayList<SanPham> getListSPHot() {
		return listSPHot;
	}
	public void setListSPHot(ArrayList<SanPham> listSPHot) {
		this.listSPHot = listSPHot;
	}
	public ArrayList<SanPham> getListSP() {
		return listSP;
	}
	public void setListSP(ArrayList<SanPham> listSP) {
		this.listSP = listSP;
	}
	public String getTimKiem() {
		return timKiem;
	}
	public void setTimKiem(String timKiem) {
		this.timKiem = timKiem;
	}
	public String getLoaiSP() {
		return loaiSP;
	}
	public void setLoaiSP(String loaiSP) {
		this.loaiSP = loaiSP;
	}
	public String getTrangThai() {
		return trangThai;
	}
	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}
	
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
