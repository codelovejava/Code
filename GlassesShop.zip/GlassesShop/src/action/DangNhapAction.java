package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DangNhapForm;
import model.bo.DangNhapBO;

public class DangNhapAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
//		HttpSession session =  request.getSession();
//		session.invalidate();
		
		DangNhapForm dangNhapForm=(DangNhapForm) form;
		DangNhapBO dangNhapBO=new DangNhapBO();
		String user=dangNhapForm.getUserName();
		String pass=dangNhapForm.getMatKhau();
		if(dangNhapBO.checkKhachHang(user, pass)){
			dangNhapForm.setTrangThai(user);
			System.out.println("Thanh Cong");
			return mapping.findForward("thanhCong");
		}else if(dangNhapBO.checkAdmin(user, pass)){
			return mapping.findForward("admin");
		}
		return mapping.findForward("thatBai");
	}
	

}
