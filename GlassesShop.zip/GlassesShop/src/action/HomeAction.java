package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.SanPham;
import form.DangNhapForm;
import model.bo.SanPhamBO;

public class HomeAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String trangThai="Dang Nhap";
		DangNhapForm dangNhapForm=(DangNhapForm) form;
		SanPhamBO sp=new SanPhamBO();
		ArrayList<SanPham> listSP=sp.getListSanPham();
		dangNhapForm.setListSP(listSP);
		
		HttpSession session = request.getSession();
		int soSanPham = 0;
		
		if(session.getAttribute("listSanPhamSession") != null)
		{
			if(session.getAttribute("soSanPham") != null)
			{
				 ArrayList<SanPham> listSanPham = ( ArrayList<SanPham>)session.getAttribute("listSanPhamSession");
				 soSanPham = listSanPham.size();
				 session.setAttribute("soSanPham", soSanPham);
			}
			else if(session.getAttribute("soSanPham") == null)
			{
				session.setAttribute("soSanPham", soSanPham);
			}
		}
		else
		{
			session.setAttribute("soSanPham", soSanPham);
		}
		return mapping.findForward("loadHome");
	}

}
