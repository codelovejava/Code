package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.KhachHang;
import form.ChamSocKH;
import model.bo.KhachHangBO;

public class ChamSocKhachHangAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ChamSocKH kh=(ChamSocKH) form;
		String userName=kh.getUserName();
		KhachHangBO khBO=new KhachHangBO();
		int maKH=khBO.getMa(userName);
		String hoTen=khBO.getHoTen(maKH);
		System.out.println(hoTen);
		float doCan=khBO.getDoCan(maKH);
		KhachHang khachHang=khBO.getKhachHang(maKH);
		String noiDung=khBO.getThongTinChamSoc(doCan);
		kh.setDoCan(doCan);
		kh.setNoiDung(noiDung);
		kh.setNoiDungGoiY(khBO.getCoTheBanChuaBiet());
		kh.setTenKH(hoTen);
		kh.setKhachHang(khachHang);
		return mapping.findForward("chamSocThanhCong");
	}

}
