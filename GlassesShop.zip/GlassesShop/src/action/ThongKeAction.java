package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.ThongKe;
import form.ThongKeForm;
import model.bo.ThongKeBO;

public class ThongKeAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ThongKeForm thongKeForm=(ThongKeForm) form;
		ThongKeBO thKeBO=new ThongKeBO();
		ThongKe tk=thKeBO.getToanBoThongKe();
		thongKeForm.setThongKe(tk);
		return mapping.findForward("thongKeToanBo");
	}

}
