package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.SanPham;
import model.bo.SanPhamBO;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.taglibs.standard.lang.jstl.test.StaticFunctionTests;

import form.GioHangForm;

public class GioHangAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		GioHangForm gioHangForm = (GioHangForm) form;

		SanPhamBO sp=new SanPhamBO();
		HttpSession session = request.getSession();

		if (gioHangForm.getMaSP().equalsIgnoreCase("") && session.getAttribute("listSanPhamSession") == null) {
			System.out.println("khong co hang");
			if(session.getAttribute("soSanPham") == null)
			{
				session.removeAttribute("soSanPham");
				int soSanPham = 0;
				session.setAttribute("soSanPham", soSanPham);
				
			}
			return mapping.findForward("KhongCoHang");
		} 
		else if(gioHangForm.getMaSP().equalsIgnoreCase("") && session.getAttribute("listSanPhamSession") != null)
		{
			System.out.println("home");
			ArrayList<SanPham> listSanPham = new ArrayList<SanPham>();
			listSanPham = (ArrayList<SanPham>) session.getAttribute("listSanPhamSession");
			gioHangForm.setListSanPham(listSanPham);
			
			int soSanPham = listSanPham.size();
			session.removeAttribute("soSanPham");
			session.setAttribute("soSanPham", soSanPham);
			
			return mapping.findForward("CoHang");
		}
		else {
			if (!gioHangForm.getMaSP().equalsIgnoreCase("") && session.getAttribute("listSanPhamSession") == null) {
				ArrayList<SanPham> listSanPham = new ArrayList<SanPham>();
				String maSP = gioHangForm.getMaSP();
				int maSPInt = Integer.parseInt(maSP);
				
				SanPham sanPham = sp.getSanPham(maSPInt);

				listSanPham.add(sanPham);
				session.setAttribute("listSanPhamSession", listSanPham);
				System.out.println("1");
				gioHangForm.setTongTien(listSanPham.get(0).getGiaTien());
				gioHangForm.setListSanPham(listSanPham);
				
				session.removeAttribute("soSanPham");
				int soSanPham = 1;
				session.setAttribute("soSanPham", soSanPham);
				
				
			} else if (!gioHangForm.getMaSP().equalsIgnoreCase("") && session.getAttribute("listSanPhamSession") != null) {
				ArrayList<SanPham> listSanPham = new ArrayList<SanPham>();
				listSanPham = (ArrayList<SanPham>) session.getAttribute("listSanPhamSession");
				session.removeAttribute("listSanPhamSession");
				System.out.println("2");
				String maSP = gioHangForm.getMaSP();
				int maSPInt = Integer.parseInt(maSP);
				
				SanPham sanPham = sp.getSanPham(maSPInt);
				
				boolean check = true;
				for(int i=0; i< listSanPham.size(); i++)
				{
					if(sanPham.getMaSP() == listSanPham.get(i).getMaSP())
					{
						check = false;
						break;
					}		
				}
				
				if(check)
				{
					listSanPham.add(sanPham);
				}
				
				float tongTien = 0;
				
				for(int i=0;i < listSanPham.size(); i++)
				{
					tongTien += listSanPham.get(i).getGiaTien();
				}
				
				gioHangForm.setTongTien(tongTien);
				gioHangForm.setListSanPham(listSanPham);
				session.setAttribute("listSanPhamSession", listSanPham);
				
				session.removeAttribute("soSanPham");
				int soSanPham = listSanPham.size();
				session.setAttribute("soSanPham", soSanPham);
			}
			return mapping.findForward("CoHang");
		}
	}
}
