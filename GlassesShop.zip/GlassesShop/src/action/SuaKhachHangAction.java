package action;

import java.sql.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.KhachHang;
import form.KhachHangForm;
import model.bo.KhachHangBO;
import model.dao.KhachHangDAO;

public class SuaKhachHangAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		KhachHangForm khachHangForm=(KhachHangForm) form;
		KhachHangBO khachHangBO=new KhachHangBO();
		int maKH=khachHangForm.getMaKH();
		KhachHang khachHang=khachHangBO.getKhachHang(maKH);
		khachHangForm.setTenKH(khachHang.getTenKH());
		khachHangForm.setMaKH(khachHang.getMaKH());
		khachHangForm.setDiaChi(khachHang.getDiaChi());
		khachHangForm.setEmail(khachHang.getEmail());
		khachHangForm.setSoDienThoai(khachHang.getSoDienThoai());
		khachHangForm.setNgaySinh(khachHang.getNgaySinh());
		khachHangForm.setUserName(khachHang.getUserName());
		khachHangForm.setMatKhau(khachHang.getMatKhau());
		khachHangForm.setMaGD(khachHang.getMaGD());
		if("submit".equals(khachHangForm.getSubmit())){
			String tenKh=khachHangForm.getTenKH();
			String ngaySinh= khachHangForm.getNgaySinh();
			String diaChi=khachHangForm.getDiaChi();
			String soDienThoai=khachHangForm.getSoDienThoai();
			String email=khachHangForm.getEmail();
			String matKhau=khachHangForm.getMatKhau();
			int maGD=khachHangForm.getMaGD();
			String userName=khachHangForm.getUserName();
			System.out.println("bncvashv");
			boolean kq=khachHangBO.suaKhachHang(tenKh,ngaySinh, diaChi, soDienThoai, email, matKhau, maGD, userName,maKH);
			if(kq){
				return mapping.findForward("suaKHxong");
			}
		}
		return mapping.findForward("suaKH");
	}
}
