package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.SanPham;
import form.SanPhamForm;
import model.bo.SanPhamBO;

public class TimKiemAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		SanPhamForm sanPhamForm = (SanPhamForm) form;
		String tuKhoa = sanPhamForm.getTuKhoa();
		String searchISO= sanPhamForm.getSearch();
		System.out.println(searchISO);
		String search=new String(searchISO.getBytes("ISO-8859-1"), "UTF-8");
		System.out.println(search);
		String timKiem = null;
		SanPhamBO sanPhamBO = new SanPhamBO();
		ArrayList<SanPham> listSP = new ArrayList<SanPham>();
		if ("Gia".equals(tuKhoa)) {
			listSP = sanPhamBO.timSPGia();
			sanPhamForm.setListSP(listSP);
			return mapping.findForward("TKthanhCong");
		}
		if ("NamSanXuat".equals(tuKhoa)) {
			listSP = sanPhamBO.timSPGia();
			sanPhamForm.setListSP(listSP);
			return mapping.findForward("TKthanhCong");
		}
		if (("".equals(tuKhoa) || tuKhoa.isEmpty() || tuKhoa == null) && ("".equals(search) || search.isEmpty())
				|| search == null) {
			listSP = sanPhamBO.getListSanPham();
			sanPhamForm.setListSP(listSP);
			return mapping.findForward("TKthanhCong");
		} else {
			if ((sanPhamBO.timKiemSP(search).size()<=0) ||sanPhamBO.timKiemSP(search)==null) {
				if(sanPhamBO.timTuKhoa(search.toUpperCase())!=null){
					timKiem = sanPhamBO.timTuKhoa(search.toUpperCase());
					System.out.println(timKiem);
					listSP=sanPhamBO.timKiemSP(timKiem);
					sanPhamForm.setListSP(listSP);
					return mapping.findForward("TKthanhCong");
				}
			}else{
				listSP=sanPhamBO.timKiemSP(search);
				sanPhamForm.setListSP(listSP);
				return mapping.findForward("TKthanhCong");
			}
		}
		sanPhamBO.timKiemThatBai(search.toUpperCase());
		return mapping.findForward("timKiemThatBai");
	}

}
