package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bo.ThongKeBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ThongKeForm;
import form.TimKiemForm;

public class SuaTuKhoaAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		TimKiemForm tk = (TimKiemForm) form;
		String tuKhoaISO = tk.getTuKhoa();
		String tuKhoa = new String(tuKhoaISO.getBytes("ISO-8859-1"), "UTF-8");
		ThongKeBO tBo = new ThongKeBO();
		if ("submit".equals(tk.getSubmit())) {
			String tuKhoaCoTheISO = tk.getTuTimKiemCoThe();
			String tuKhoaCoThe = new String(tuKhoaCoTheISO.getBytes("ISO-8859-1"), "UTF-8");
			if (tBo.suaTuKhoa(tuKhoa, tuKhoaCoThe)) {
				return mapping.findForward("suaTKThanhCong");
			}
		}

		return mapping.findForward("suaTKThatBai");
	}
}
