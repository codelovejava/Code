package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bo.KhachHangBO;
import model.bo.ThongKeBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.KhachHang;
import bean.TimKiem;
import form.KhachHangForm;
import form.TimKiemForm;

public class TuKhoaAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		TimKiemForm tk=(TimKiemForm) form;
		ThongKeBO thongKeBO=new ThongKeBO();
		ArrayList<TimKiem> listTK=thongKeBO.getThongTinTK();
		tk.setListTK(listTK);
		return mapping.findForward("daTuKhoa");
	}

}
