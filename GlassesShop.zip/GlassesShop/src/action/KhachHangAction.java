package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.KhachHang;
import form.KhachHangForm;
import model.bo.KhachHangBO;

public class KhachHangAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		KhachHangForm khachHangForm=(KhachHangForm) form;
		KhachHangBO khachHangBO=new KhachHangBO();
		ArrayList<KhachHang> listKH=khachHangBO.getListKhachHang();
		khachHangForm.setListKH(listKH);
		return mapping.findForward("dsKhachhang");
	}
}
