package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bo.KhachHangBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.KhachHangForm;

public class XoaKhachHangAction extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		KhachHangForm kh=(KhachHangForm) form;
		int maKH=kh.getMaKH();
		System.out.println(maKH);
		KhachHangBO bo=new KhachHangBO();
		if(bo.xoaKH(maKH)){
			return mapping.findForward("xoaThanhCong");
		}
		return mapping.findForward("xoaThatBai");
	}
}
