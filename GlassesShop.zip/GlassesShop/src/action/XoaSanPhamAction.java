package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.GioHangForm;
import form.SanPhamForm;
import form.XoaSanPhamForm;

import bean.SanPham;

public class XoaSanPhamAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession();
		
		ArrayList<SanPham> listSanPham = (ArrayList<SanPham>) session.getAttribute("listSanPhamSession");
		SanPhamForm sanPhamForm = (SanPhamForm) form;
		
		String  maSP1 = sanPhamForm.getMaSP();
		int maSP = Integer.parseInt(maSP1);
		
		System.out.println("masp:" + maSP);
		
		System.out.println("size:" + listSanPham.size());
		
		System.out.println("msp_list:" + listSanPham.get(0).getMaSP());
		
		
		for(int i=0; i<listSanPham.size(); i++)
		{
			if(maSP == listSanPham.get(i).getMaSP())
			{
				listSanPham.remove(i);
			}
		}
		System.out.println("size:" + listSanPham.size());
		
		if(listSanPham.isEmpty())
		{
			session.removeAttribute("listSanPhamSession");
			session.removeAttribute("soSanPham");
		}
		else
		{	
			session.removeAttribute("listSanPhamSession");
			session.setAttribute("listSanPhamSession", listSanPham);
			
		}
		
		return mapping.findForward("xoaXong");
	}
}
