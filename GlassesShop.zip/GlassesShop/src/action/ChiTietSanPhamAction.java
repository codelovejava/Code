package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.SanPham;
import form.SanPhamForm;
import model.bo.SanPhamBO;

public class ChiTietSanPhamAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SanPhamForm sanPhamForm=(SanPhamForm) form;
		String maSP=sanPhamForm.getMaSP();
		SanPhamBO sanPhamBO=new SanPhamBO();
		
		int tg=Integer.parseInt(maSP);
		
		
		SanPham sanPham=sanPhamBO.getThongTinSP(tg);
		ArrayList<SanPham> listSP=sanPhamBO.getSanPhamTheoDM(tg);
		
		sanPhamForm.setListSP(listSP);
		sanPhamForm.setSanPham(sanPham);
		sanPhamForm.setUrlImage(sanPham.getUrlImage());
		
		return mapping.findForward("chiTietSP");
	}
}
