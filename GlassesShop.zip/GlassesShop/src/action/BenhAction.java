package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.Benh;
import form.BenhForm;
import model.bo.BenhBO;

public class BenhAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		 request.setCharacterEncoding("UTF-8");
		 response.setCharacterEncoding("UTF-8");
		 
		BenhForm bf = (BenhForm) form;
		
		String timKiem = bf.getTimKiem();
		
		if(timKiem==null || timKiem.length()==0)
			return mapping.findForward("chuacobenh");
		
		String timKiemUTF8=new String(timKiem.getBytes("ISO-8859-1"), "UTF-8");
		String dieuKien = bf.getDieuKien();
		
		System.out.println(timKiem);
		System.out.println(dieuKien);
		
		
		if(dieuKien.equalsIgnoreCase("theoTen"))
		{
			ArrayList<Benh> listBenh = BenhBO.getListBenh(timKiemUTF8);
			
			if(listBenh.isEmpty())
				return mapping.findForward("chuacobenh");
			else	
				bf.setListBenh(listBenh);
		}
		else if(dieuKien.equalsIgnoreCase("theoTrieuChung"))
		{
			ArrayList<Benh> listBenh = BenhBO.getListBenhTheoBenhLy(timKiemUTF8);
			
			if(listBenh.isEmpty())
				return mapping.findForward("chuacobenh");
			else
				bf.setListBenh(listBenh);
		}
		return mapping.findForward("danhsachbenh");
	}
}
