package action;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import bean.KhachHang;
import form.KhachHangForm;
import form.SanPhamForm;
import model.bo.KhachHangBO;
import model.bo.SanPhamBO;

public class SuaSanPhamAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SanPhamForm khachHangForm=(SanPhamForm) form;
		SanPhamBO sanPhamBO=new SanPhamBO();
		return mapping.findForward("suaKH");
	}
}
