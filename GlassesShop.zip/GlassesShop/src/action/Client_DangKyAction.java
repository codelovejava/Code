package action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bo.KhachHangBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import form.Client_DangKy;

public class Client_DangKyAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		Client_DangKy dangKy = (Client_DangKy) form;
		System.out.println("aaaa");
		String tenKh = dangKy.getTenKH();
		String diaChi = dangKy.getDiaChi();
		String email = dangKy.getEmail();
		String maGD = dangKy.getMaGD();
		System.out.println("125132");
		String sdt = dangKy.getSoDienThoai();
		String userName = dangKy.getUserName();
		String matKhau = dangKy.getMatKhau();
		String ngaySinh =dangKy.getNgaySinh();
		KhachHangBO khbo = new KhachHangBO();
		
		int kq=khbo.chenKhachHang(tenKh, ngaySinh, diaChi, sdt, email, matKhau, maGD, userName);
		if(kq>0){
			return mapping.findForward("dangkythanhcong");
		}
		return mapping.findForward("dangkyThatBai");
	}
}
