package bean;

import java.sql.Date;

public class UuDai {
	private int maUD;
	private String tenUD;
	private String moTa;
	private Date ngayBatDau;
	private int maSP;
	private String tenSP;
	private String moTaUD;
	private Date ngayKetThuc;
	
	public int getMaSP() {
		return maSP;
	}
	public void setMaSP(int maSP) {
		this.maSP = maSP;
	}
	public int getMaUD() {
		return maUD;
	}
	public void setMaUD(int maUD) {
		this.maUD = maUD;
	}
	public String getTenUD() {
		return tenUD;
	}
	public void setTenUD(String tenUD) {
		this.tenUD = tenUD;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public Date getNgayBatDau() {
		return ngayBatDau;
	}
	public void setNgayBatDau(Date ngayBatDau) {
		this.ngayBatDau = ngayBatDau;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public String getMoTaUD() {
		return moTaUD;
	}
	public void setMoTaUD(String moTaUD) {
		this.moTaUD = moTaUD;
	}
	public Date getNgayKetThuc() {
		return ngayKetThuc;
	}
	public void setNgayKetThuc(Date ngayKetThuc) {
		this.ngayKetThuc = ngayKetThuc;
	}
	

}
