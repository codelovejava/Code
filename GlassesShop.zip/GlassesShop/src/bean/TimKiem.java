package bean;

public class TimKiem {
	private String tuKhoa;
	private String tuTimKiemCoThe;
	private int luotXem;
	public String getTuKhoa() {
		return tuKhoa;
	}
	public void setTuKhoa(String tuKhoa) {
		this.tuKhoa = tuKhoa;
	}
	public String getTuTimKiemCoThe() {
		return tuTimKiemCoThe;
	}
	public void setTuTimKiemCoThe(String tuTimKiemCoThe) {
		this.tuTimKiemCoThe = tuTimKiemCoThe;
	}
	public int getLuotXem() {
		return luotXem;
	}
	public void setLuotXem(int luotXem) {
		this.luotXem = luotXem;
	}
	
}
