package bean;

public class Benh {
	private String tenBenh;
	private String moTa;
	private String nenLam;
	private String khongNenLam;
	private String nguyenNhan;
	
	
	public String getTenBenh() {
		return tenBenh;
	}
	public void setTenBenh(String tenBenh) {
		this.tenBenh = tenBenh;
	}
	public String getMoTa() {
		return moTa;
	}
	public void setMoTa(String moTa) {
		this.moTa = moTa;
	}
	public String getNenLam() {
		return nenLam;
	}
	public void setNenLam(String nenLam) {
		this.nenLam = nenLam;
	}
	public String getKhongNenLam() {
		return khongNenLam;
	}
	public void setKhongNenLam(String khongNenLam) {
		this.khongNenLam = khongNenLam;
	}
	public String getNguyenNhan() {
		return nguyenNhan;
	}
	public void setNguyenNhan(String nguyenNhan) {
		this.nguyenNhan = nguyenNhan;
	}
	
	
	
}
