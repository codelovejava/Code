package bean;

public class ThongKe {
	private int soLuongKH;
	private float phanTramSP;
	private float soLanSale;
	private int doanhSo;
	private int nam;
	public int getSoLuongKH() {
		return soLuongKH;
	}
	public void setSoLuongKH(int soLuongKH) {
		this.soLuongKH = soLuongKH;
	}
	public float getPhanTramSP() {
		return phanTramSP;
	}
	public void setPhanTramSP(float phanTramSP) {
		this.phanTramSP = phanTramSP;
	}
	public float getSoLanSale() {
		return soLanSale;
	}
	public void setSoLanSale(float soLanSale) {
		this.soLanSale = soLanSale;
	}
	public int getDoanhSo() {
		return doanhSo;
	}
	public void setDoanhSo(int doanhSo) {
		this.doanhSo = doanhSo;
	}
	public int getNam() {
		return nam;
	}
	public void setNam(int nam) {
		this.nam = nam;
	}
	

}
