package bean;

public class ChamSocKhachHang {
	private float doCan;
	private String noiDung;
	
	public float getDoCan() {
		return doCan;
	}
	public void setDoCan(float doCan) {
		this.doCan = doCan;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}


}
