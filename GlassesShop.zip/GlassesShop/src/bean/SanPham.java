package bean;

import java.util.Date;

/**
 * @author HCD-Fresher027
 * create Object SanPham
 *
 */
public class SanPham {
	private int maSP;
	private String tenSP;
	private int soLuong;
	private float giaTien;
	private String xuatXu;
	private int maDM;
	private Date ngayNhapVe;
	private String urlImage;
	private String tenDM;
	private int maUD;
	public int getMaSP() {
		return maSP;
	}
	public void setMaSP(int maSP) {
		this.maSP = maSP;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public int getSoLuong() {
		return soLuong;
	}
	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}
	public float getGiaTien() {
		return giaTien;
	}
	public void setGiaTien(float giaTien) {
		this.giaTien = giaTien;
	}
	public String getXuatXu() {
		return xuatXu;
	}
	public void setXuatXu(String xuatXu) {
		this.xuatXu = xuatXu;
	}
	public int getMaDM() {
		return maDM;
	}
	public void setMaDM(int maDM) {
		this.maDM = maDM;
	}
	public Date getNgayNhapVe() {
		return ngayNhapVe;
	}
	public void setNgayNhapVe(Date ngayNhapVe) {
		this.ngayNhapVe = ngayNhapVe;
	}
	public String getUrlImage() {
		return urlImage;
	}
	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}
	public String getTenDM() {
		return tenDM;
	}
	public void setTenDM(String tenDM) {
		this.tenDM = tenDM;
	}
	public int getMaUD() {
		return maUD;
	}
	public void setMaUD(int maUD) {
		this.maUD = maUD;
	}
	public double getTotalPrice(){
		return giaTien*soLuong;
	}
	
	
	
}
