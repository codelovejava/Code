package bean;

public class CoTheBanChuaBiet {
	private int maND;
	private String noiDungGoiY;
	public int getMaND() {
		return maND;
	}
	public void setMaND(int maND) {
		this.maND = maND;
	}
	public String getNoiDungGoiY() {
		return noiDungGoiY;
	}
	public void setNoiDungGoiY(String noiDungGoiY) {
		this.noiDungGoiY = noiDungGoiY;
	}
	
}
