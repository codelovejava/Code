package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.xml.transform.sax.SAXTransformerFactory;

import bean.ChamSocKhachHang;
import bean.CoTheBanChuaBiet;
import bean.KhachHang;

public class KhachHangDAO {
	public KhachHang getKhachHang(int maKH){
		KhachHang kh=new KhachHang();
		String sql=String.format("select * from KHACHHANG where MaKH='%d'", maKH);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				kh.setMaKH(rs.getInt("MaKH"));
				kh.setTenKH(rs.getString("TenKH"));
				kh.setNgaySinh(rs.getString("NgaySinh"));
				kh.setDiaChi(rs.getString("DiaChi"));
				kh.setSoDienThoai(rs.getString("SoDienThoai"));
				kh.setEmail(rs.getString("Email"));
				kh.setMatKhau(rs.getString("MatKhau"));
				kh.setMaGD(rs.getInt("MaGiaDinh"));
				kh.setUserName(rs.getString("UserName"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return kh;
	}
	public ArrayList<KhachHang> getListKhachHang(){
		ArrayList<KhachHang> listKH=new ArrayList<KhachHang>();
		String sql=String.format("select * from KHACHHANG");
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				KhachHang kh=new KhachHang();
				kh.setMaKH(rs.getInt("MaKH"));
				kh.setTenKH(rs.getString("TenKH"));
				kh.setNgaySinh(rs.getString("NgaySinh"));
				kh.setDiaChi(rs.getString("DiaChi"));
				kh.setSoDienThoai(rs.getString("SoDienThoai"));
				kh.setEmail(rs.getString("Email"));
				kh.setMatKhau(rs.getString("MatKhau"));
				kh.setMaGD(rs.getInt("MaGiaDinh"));
				kh.setUserName(rs.getString("UserName"));
				listKH.add(kh);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listKH;
	}
	public int chenKhachHang(String tenKh,String ngaySinh,String diaChi,String sdt,String email,String matKhau,String maGD,String userName){
		int kq=0;
		String sql=String.format("insert into KHACHHANG(TenKH,NgaySinh,DiaChi,SoDienThoai,Email,MatKhau,MaGiaDinh,UserName)"
				+ "values('%s','%s','%s','%s','%s','%s','%d','%s')"
				, tenKh,ngaySinh,diaChi,sdt,email,matKhau,1,userName);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return kq;
	}
	public boolean suaKhachHang(String tenKh,String ngaySinh,String diaChi,String sdt,String email,String matKhau,int maGD,String userName,int maKH){
		int kq=0;
		String sql=String.format("update KHACHHANG set TenKH='%s',NgaySinh='%s'," +
				"DiaChi='%s',SoDienThoai='%s',Email='%s',MatKhau='%s',MaGiaDinh=%d," +
				"UserName='%s' where MaKH=%d"
				,tenKh,ngaySinh,diaChi,sdt,email,matKhau,maGD,userName,maKH);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
		
	}
	public String getCoTheBanChuaBiet(){
		String banChuaBiet=null;
		Random rd=new Random();
		int maND=rd.nextInt(10);
		String sql=String.format("select * from COTHEBANTHUABIET where MaND=%d", maND);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				banChuaBiet=rs.getString("NoiDung");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return banChuaBiet;
		
	}
	public float getDoCan(int maKH){
		float doCan=0;
		String sql=String.format("select DoCan from V_DoCan where MaKH=%d", maKH);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			ResultSet rs1;
			while(rs.next()){
				doCan=rs.getFloat("doCan");
			}
//			if(doCan<=1.5){
//				String sql1="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Nhe'";
//				rs1=st.executeQuery(sql1);
//			}else if(doCan>1.5 && doCan<=3){
//				String sql2="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Trung Binh'";
//				rs1=st.executeQuery(sql2);
//			}
//			else{
//				String sql3="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Nang'";
//				rs1=st.executeQuery(sql3);
//			}
//			while(rs1.next()){
//				chamSocKhachHang.setDoCan(doCan);
//				chamSocKhachHang.setNoiDung(rs.getString("LoiKhuyen"));
//			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doCan;
		
	}
	public int getMa(String userName){
		String sql=String.format("select MaKH from KHACHHANG where UserName='%s' ", userName);
		int ma=0;
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				ma=rs.getInt("MaKH");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ma;
	}
	public String getHoTen(int id){
		String hoTen = null;
		String sql=String.format("select TenKH from KHACHHANG where MaKH=%d", id);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				hoTen=rs.getString("TenKH");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hoTen;
	}
	public String getThongTinChamSoc(float doCan){
		String noiDung=null;
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs;
			if(doCan<=1.5){
				String sql1="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Nhe'";
				rs=st.executeQuery(sql1);
			}else if(doCan>1.5 && doCan<=3){
				String sql2="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Trung Binh'";
				rs=st.executeQuery(sql2);
			}
			else{
				String sql3="select LoiKhuyen from CHAMSOCKHACHHANG where MucDo='Nang'";
				rs=st.executeQuery(sql3);
			}
			while(rs.next()){
				noiDung=rs.getString("LoiKhuyen");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noiDung;
	}
	public boolean xoaKH(int maKH){
		int kq=0;
		String sql=String.format("delete from KHACHHANG where MaKH=%d",maKH);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
		
	}
	
	

}
