package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.SanPham;

public class SanPhamDAO {
	public ArrayList<SanPham> getListSanPham(){
		ArrayList<SanPham> listSP=new ArrayList<SanPham>();
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			String sql="select top 6 * from SANPHAM";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				SanPham sp=new SanPham();
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				listSP.add(sp);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSP;
	}
	public  ArrayList<SanPham> getSanPham(String tenDM){
		String sql = "select distinct a.masp,tensp,soluong,giatien,xuatxu,a.madm,ngaynhapve,urlimage,tendm" +
				" from [sanpham] a inner join [danhmucsp] b on a.madm = b.madm  where tendm=?";
		ArrayList<SanPham> listSanPham = new ArrayList<SanPham>();
		
		try {
			PreparedStatement ps=ConnectDB.connectDB().prepareStatement(sql);
			ps.setString(1, tenDM);
			
			ResultSet rs = ps.executeQuery();
			
			
			while(rs.next())
			{
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt(1));
				sp.setTenSP(rs.getString(2));
				sp.setSoLuong(rs.getInt(3));
				sp.setGiaTien(rs.getFloat(4));
				sp.setXuatXu(rs.getString(5));
				sp.setMaDM(rs.getInt(6));
				sp.setNgayNhapVe(rs.getDate(7));
				sp.setUrlImage(rs.getString(8));
				sp.setTenDM(rs.getString(9));
				
				listSanPham.add(sp);
			}
			return listSanPham;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<SanPham> spTheoGia(){
		ArrayList<SanPham> listSPGia=new ArrayList<SanPham>();
		String sql="select top 6 * from SANPHAM order by GiaTien asc";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				
				
				listSPGia.add(sp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSPGia;
		
	}
	public ArrayList<SanPham> spTheoNamSanXuat(){
		ArrayList<SanPham> listSPGia=new ArrayList<SanPham>();
		String sql="select top 6 * from SANPHAM order by NgayNhapVe asc";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				
				
				listSPGia.add(sp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSPGia;
		
	}
	public SanPham getThongTinSP(int maSP){
		SanPham sp=new SanPham();
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			String sql=String.format("select * from SANPHAM where MaSP=%d",maSP);
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sp;
		
	}
	public ArrayList<SanPham> topSPBanChay(){
		ArrayList<SanPham> listSPChay=new ArrayList<SanPham>();
		String sql="select top 10  * from V_spBanChay";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				
				listSPChay.add(sp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSPChay;	
	}
	public ArrayList<SanPham> getSanPhamTheoDM(int maSP){
		ArrayList<SanPham> listSPDM=new ArrayList<SanPham>();
		String sql=String.format("select * from SANPHAM where MaDM =(select MaDM from SANPHAM where MaSP=%d )",maSP);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				listSPDM.add(sp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSPDM;
	}
	public String timTuKhoa(String tuKhoa){
		String abc=""+tuKhoa+"%";
		String tuKhoaTK=null;
		String sql=String.format("select distinct TuTimKiemCoThe from TUKHOA where TuKhoa like N'%s'", tuKhoa);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				tuKhoaTK=rs.getString("TuTimKiemCoThe");
			}
		} catch (SQLException e) {
			return tuKhoaTK;
		}
		return tuKhoaTK;
	}
	public ArrayList<SanPham> timKiemSP(String tuKhoa){
		String timKiem="%"+tuKhoa+"%";
		ArrayList<SanPham> listSP=new ArrayList<SanPham>();
		String sql=String.format("select * from SANPHAM where (MaSP in (select MaSP from V_SPTimKiem where" +
				" TenSP like '%s' or MoTaDM like N'%s' " +
				"or XuatXu like N'%s' or TheLoai like '%s' " +
				"or TenDM like N'%s' or MoTaUD like N'%s' " +
				"or TenUD like N'%s' or MoTaLUD like N'%s'))" ,timKiem,timKiem,timKiem,timKiem,timKiem,timKiem,timKiem,timKiem);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				listSP.add(sp);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSP;
	}
	public ArrayList<SanPham> timSPGia(){
		ArrayList<SanPham> listSP=new ArrayList<SanPham>();
		String sql="select top 10 * from SANPHAM order by GiaTien";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				SanPham sp=new SanPham();
				
				sp.setMaSP(rs.getInt("MaSP"));
				sp.setTenSP(rs.getString("TenSP"));
				sp.setSoLuong(rs.getInt("SoLuong"));
				sp.setGiaTien(rs.getFloat("GiaTien"));
				sp.setXuatXu(rs.getString("XuatXu"));
				sp.setMaDM(rs.getInt("MaDM"));
				sp.setNgayNhapVe(rs.getDate("NgayNhapVe"));
				sp.setUrlImage(rs.getString("UrlImage"));
				listSP.add(sp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listSP;
		
	}
	public static SanPham getSanPham(int maSP){
		String sql = "select * from [sanpham] where masp=?";
		
		Connection con = ConnectDB.connectDB();
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, maSP);
			ResultSet rs = ps.executeQuery();
			
			rs.next();
			SanPham sp = new SanPham();
			
			sp.setMaSP(rs.getInt(1));
			sp.setTenSP(rs.getString(2));
			sp.setSoLuong(rs.getInt(3));
			sp.setGiaTien(rs.getFloat(4));
			sp.setXuatXu(rs.getString(5));
			sp.setMaDM(rs.getInt(6));
			sp.setNgayNhapVe(rs.getDate(7));
			sp.setUrlImage(rs.getString(8));
			
			return sp;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	
	}
	public boolean timKiemThatBai(String search){
		int kq=0;
		String sql=String.format("insert into TUKHOA(TuKhoa) values ('%s')", search);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
	}
	public static void main(String[] args) {
		SanPhamDAO sp=new SanPhamDAO();
		ArrayList<SanPham> lt=sp.getSanPham("Kinh Tre Em");
		for (SanPham sanPham : lt) {
			System.out.println(sanPham.getTenSP());
		}
	}
	
	

}
