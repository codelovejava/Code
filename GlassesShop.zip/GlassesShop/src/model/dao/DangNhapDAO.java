package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DangNhapDAO {
	public boolean checkKhachHang(String userName,String matKhau){
		ResultSet rs=null;
		String sql=String.format("select * from KHACHHANG where UserName='%s' and MatKhau='%s'", userName,matKhau);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			rs=st.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	public boolean checkAdmin(String userName,String matKhau){
		if(userName.equals("admin")&&matKhau.equals("12345")){
			return true;
		}
		return false;
	}

}
