package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.ThongKe;
import bean.TimKiem;

public class ThongKeDAO {
	public ThongKe getThongKe(int nam){
		ThongKe tk=new ThongKe();
		try {
			String sql=String.format("select * from f_doanhso('%s') ", nam);
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				tk.setSoLuongKH(rs.getInt("SlKhachhang"));
				tk.setPhanTramSP(rs.getFloat("PhanTramSpban"));
				tk.setSoLanSale(rs.getFloat("SolanSale"));
				tk.setDoanhSo(rs.getInt("DoanhSo"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tk;
	}
	public ThongKe getToanBoThongKe(){
		ThongKe tk=new ThongKe();
		try {
			String sql="select * from f_doanhsocuahang() ";
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				tk.setSoLuongKH(rs.getInt("SlKhachhang"));
				tk.setPhanTramSP(rs.getFloat("PhanTramSpban"));
				tk.setSoLanSale(rs.getInt("SolanSale"));
				tk.setDoanhSo(rs.getInt("DoanhSo"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tk;
	}
	public ArrayList<TimKiem> getThongTinTK(){
		ArrayList<TimKiem> listTK=new ArrayList<TimKiem>();
		String sql="select * from TUKHOA";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				TimKiem tk=new TimKiem();
				tk.setTuKhoa(rs.getString("TuKhoa"));
				tk.setTuTimKiemCoThe(rs.getString("TuTimKiemCoThe"));
				tk.setLuotXem(rs.getInt("SoLuotTK"));
				listTK.add(tk);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listTK;
	}
	public TimKiem getTuKhoa(String TuKhoa){
		TimKiem tk=new TimKiem();
		String sql="select * from TUKHOA where TuKhoa=N'%s'";
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				tk.setTuKhoa(rs.getString("TuKhoa"));
				tk.setTuTimKiemCoThe(rs.getString("TuTimKiemCoThe"));
				tk.setLuotXem(rs.getInt("SoLuotTK"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tk;
	}
	public boolean xoaTuKhoa(String tuKhoa){
		String tk="%"+tuKhoa+"%";
		int kq=0;
		String sql=String.format("delete from TUKHOA where TuKhoa like N'%s'", tk);
		
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
			System.out.println(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
	}
	public boolean suaTuKhoa(String tuKhoa,String tuKhoaCT){
		int kq=0;
		String tk="%"+tuKhoa+"%";
		String sql=String.format("update TUKHOA set TuTimKiemCoThe='%s' where TuKhoa=N'%s'", tuKhoaCT,tk);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
	}
	

}
