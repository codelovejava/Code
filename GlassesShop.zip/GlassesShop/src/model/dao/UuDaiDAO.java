package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.UuDai;

public class UuDaiDAO {
	public ArrayList<UuDai> getListUD(){
		ArrayList<UuDai> listUD=new ArrayList<UuDai>();
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			String sql="select * from v_dsUD";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				UuDai ud=new UuDai();
				ud.setMaUD(rs.getInt("MaUD"));
				ud.setTenUD(rs.getString("TenUD"));
				ud.setMoTa(rs.getString("MoTa"));
				ud.setMaSP(rs.getInt("MaSP"));
				ud.setMoTaUD(rs.getString("MoTaUD"));
				ud.setNgayBatDau(rs.getDate("NgayBatDau"));
				ud.setNgayKetThuc(rs.getDate("NgayKetThuc"));
				ud.setTenSP(rs.getString("TenSP"));
				listUD.add(ud);		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listUD;
	}
	public UuDai getThongTinUD(int maUD){
		UuDai ud=new UuDai();
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			String sql=String.format("select * from v_dsUD where MaUD='%d'",maUD);
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				ud.setMaUD(rs.getInt("MaUD"));
				ud.setTenUD(rs.getString("TenUD"));
				ud.setMoTa(rs.getString("MoTa"));
				ud.setMaSP(rs.getInt("MaSP"));
				ud.setMoTaUD(rs.getString("MoTaUD"));
				ud.setNgayBatDau(rs.getDate("NgayBatDau"));
				ud.setNgayKetThuc(rs.getDate("NgayKetThuc"));
				ud.setTenSP(rs.getString("TenSP"));	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ud;
	}
	public boolean xoaUD(int maUD){
		int kq=0;
		String sql=String.format("delete from UUDAI where MaUD=%d", maUD);
		try {
			Statement st=ConnectDB.connectDB().createStatement();
			kq=st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(kq>0){
			return true;
		}
		return false;
	}
}
