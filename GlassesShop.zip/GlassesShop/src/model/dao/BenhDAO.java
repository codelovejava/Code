package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Benh;

public class BenhDAO {
	public static ArrayList<Benh> getListBenh(String tenBenh)
	{
		String bien="%" + tenBenh + "%";
		String sql = String.format("select * from benh where TenBenh like N'%s'",bien);
		ArrayList<Benh> listBenh = new ArrayList<Benh>();
		try {
			Statement st =ConnectDB.connectDB().createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			 while(rs.next())
			 {
				Benh benh = new Benh();
				
				benh.setTenBenh(rs.getNString("tenbenh"));
				benh.setMoTa(rs.getNString("mota"));
				benh.setNenLam(rs.getNString("nenlam"));
				benh.setKhongNenLam(rs.getNString("khongnenlam"));
				benh.setNguyenNhan(rs.getNString("nguyennhan"));
				
				listBenh.add(benh);
			 }
			return listBenh;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}		
	}
	
	
	public static ArrayList<Benh> getListBenhTheoBenhLy(String benhLy)
	{
		String sql = "select a.tenbenh,mota,nenlam,khongnenlam,nguyennhan from [Benh] a join [benhly] b on a.tenbenh=b.tenbenh where benhLy like ?";
		ArrayList<Benh> listBenh = new ArrayList<Benh>();
		
		Connection con = ConnectDB.connectDB();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			
			ps.setString(1,"%" + benhLy + "%");
		
			
			ResultSet rs = ps.executeQuery();
			
			 while(rs.next())
			 {
				Benh benh = new Benh();
				
				benh.setTenBenh(rs.getString("tenbenh"));
				benh.setMoTa(rs.getString("mota"));
				benh.setNenLam(rs.getString("nenlam"));
				benh.setKhongNenLam(rs.getString("khongnenlam"));
				benh.setNguyenNhan(rs.getString("nguyennhan"));
				
				listBenh.add(benh);
			 }
			return listBenh;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}		
	}
	
	public static void main(String[] args) {
		System.out.println(BenhDAO.getListBenh("đau mắt").size());
	}
}
