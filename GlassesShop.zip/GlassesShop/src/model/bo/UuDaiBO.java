package model.bo;

import java.util.ArrayList;

import bean.UuDai;
import model.dao.UuDaiDAO;

public class UuDaiBO {
	UuDaiDAO ud=new UuDaiDAO();
	public ArrayList<UuDai> getListUD(){
		return ud.getListUD();
	}
	public UuDai getThongTinUD(int maUD){
		return ud.getThongTinUD(maUD);
	}
	public boolean xoaUD(int maUD){
		return ud.xoaUD(maUD);
	}

}
