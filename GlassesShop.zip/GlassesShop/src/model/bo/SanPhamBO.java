package model.bo;

import java.util.ArrayList;

import bean.SanPham;
import model.dao.SanPhamDAO;

public class SanPhamBO {
	SanPhamDAO sp=new SanPhamDAO();
	public ArrayList<SanPham> getListSanPham(){
		return sp.getListSanPham();
	}
	public ArrayList<SanPham> getSanPham(String tenDM){
		return sp.getSanPham(tenDM);
	}
	public SanPham getThongTinSP(int maSP){
		return sp.getThongTinSP(maSP);
	}
	public ArrayList<SanPham> getSanPhamTheoDM(int maSP){
		return sp.getSanPhamTheoDM(maSP);
	}
	public String timTuKhoa(String tuKhoa){
		return sp.timTuKhoa(tuKhoa);
	}
	public ArrayList<SanPham> timKiemSP(String timKiem){
		return sp.timKiemSP(timKiem);
	}
	public ArrayList<SanPham> timSPGia(){
		return sp.spTheoGia();
	}
	public SanPham getSanPham(int maSP)
	{
		return sp.getSanPham(maSP);
	}
	public ArrayList<SanPham> spTheoNamSanXuat(){
		return sp.spTheoNamSanXuat();
	}
	public boolean timKiemThatBai(String search){
		return sp.timKiemThatBai(search);
	}
}
