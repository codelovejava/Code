package model.bo;

import java.util.ArrayList;

import bean.ThongKe;
import bean.TimKiem;
import model.dao.ThongKeDAO;

public class ThongKeBO {
	ThongKeDAO tk=new ThongKeDAO();
	public ThongKe getThongKe(int nam){
		return tk.getThongKe(nam);
	}
	public ThongKe getThongKe(){
		return tk.getToanBoThongKe();
	}
	public ThongKe getToanBoThongKe(){
		return tk.getToanBoThongKe();
	}
	public ArrayList<TimKiem> getThongTinTK(){
		return tk.getThongTinTK();
	}
	public TimKiem getTuKhoa(String TuKhoa){
		return tk.getTuKhoa(TuKhoa);
	}
	public boolean xoaTuKhoa(String tuKhoa){
		return tk.xoaTuKhoa(tuKhoa);
	}
	public boolean suaTuKhoa(String tuKhoa,String tuKhoaCT){
		return tk.suaTuKhoa(tuKhoa,tuKhoaCT);
	}

}
