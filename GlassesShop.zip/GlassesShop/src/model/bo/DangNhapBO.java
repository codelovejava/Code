package model.bo;

import model.dao.DangNhapDAO;

public class DangNhapBO {
	DangNhapDAO dangNhapDAO=new DangNhapDAO();
	public boolean checkKhachHang(String userName,String matKhau){
		return dangNhapDAO.checkKhachHang(userName, matKhau);
	}
	public boolean checkAdmin(String userName,String matKhau){
		return dangNhapDAO.checkAdmin(userName, matKhau);
	}
}
