package model.bo;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import bean.ChamSocKhachHang;
import bean.CoTheBanChuaBiet;
import bean.KhachHang;
import model.dao.KhachHangDAO;

public class KhachHangBO {
	KhachHangDAO khachHangDAO=new KhachHangDAO();
	public KhachHang getKhachHang(int maKH){
		return khachHangDAO.getKhachHang(maKH);
		
	}
	public ArrayList<KhachHang> getListKhachHang(){
		return khachHangDAO.getListKhachHang();
	}
	public int chenKhachHang(String tenKh,String ngaySinh,String diaChi,String sdt,String email,String matKhau,String maGD,String userName){
		return khachHangDAO.chenKhachHang(tenKh, ngaySinh, diaChi, sdt, email, matKhau, maGD, userName);
	}
	public boolean suaKhachHang(String tenKh,String ngaySinh,String diaChi,String sdt,String email,String matKhau,int maGD,String userName,int maKH){
		return khachHangDAO.suaKhachHang(tenKh, ngaySinh, diaChi, sdt, email, matKhau, maGD, userName,maKH);
	}
	public float getDoCan(int maKH){
		return khachHangDAO.getDoCan(maKH);
	}
	public String getCoTheBanChuaBiet(){
		return khachHangDAO.getCoTheBanChuaBiet();
	}
	public String getThongTinChamSoc(float doCan){
		return khachHangDAO.getThongTinChamSoc(doCan);
	}
	public int getMa(String userName){
		return khachHangDAO.getMa(userName);
	}
	public String getHoTen(int id){
		return khachHangDAO.getHoTen(id);
	}
	public boolean xoaKH(int maKH){
		return khachHangDAO.xoaKH(maKH);
	}
}
