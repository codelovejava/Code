package model.bo;

import java.util.ArrayList;

import bean.Benh;
import model.dao.BenhDAO;

public class BenhBO {
	public static ArrayList<Benh> getListBenh(String tenBenh)
	{
		return BenhDAO.getListBenh(tenBenh);
	}
	
	public static ArrayList<Benh> getListBenhTheoBenhLy(String benhLy)
	{
		return BenhDAO.getListBenhTheoBenhLy(benhLy);
	}
}
